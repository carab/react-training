
function ArticleDetail({slug}) {
  return <h1>{slug}</h1>;
}

export default ArticleDetail;
