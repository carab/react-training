import { configureStore } from "@reduxjs/toolkit";

const appReducer = {};

const store = configureStore({
  reducer: appReducer
});

export default store;
